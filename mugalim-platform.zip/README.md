# MUGALIM Платформасы 🎓

Педагогика студенттеріне арналған білім беру платформасы (Education platform for pedagogy students).

## Мүмкіндіктер / Features

- 🔐 **Аутентификация** — Кіру және тіркелу (Login & Registration)
- ✅ **Тапсырмалар** — Ай бойынша тапсырмаларды бақылау (Monthly task tracking)
- 📅 **Кесте** — Апталық сабақ кестесі (Weekly schedule, online/offline)
- 🎤 **Семинарлар** — Семинарларға тіркелу (Seminar registration)
- 📝 **Тесттер** — Таймермен тесттер (Timed quizzes with scoring)
- 💰 **Стипендия** — Стипендия ақпараты (Scholarship info & payment schedule)
- 📚 **Кітаптар** — Оқу ресурстары (Library resources by category)
- 🎓 **Курстар** — Курс бағдарламалары (Course curriculum viewer)
- 💬 **Пікір** — Кері байланыс жүйесі (Feedback system)
- 🔔 **Хабарландырулар** — Оқылмаған хабарламалар (Notifications)
- ⚙️ **Әкімші панелі** — Студенттерді, тапсырмаларды, семинарларды басқару (Admin panel)

## Жылдам бастау / Quick Start

### Талаптар / Requirements
- Node.js 18+
- npm / yarn / pnpm

### Орнату / Installation

```bash
git clone https://github.com/YOUR_USERNAME/mugalim-platform.git
cd mugalim-platform
npm install
npm run dev
```

Браузерде ашыңыз / Open in browser: `http://localhost:5173`

## Тест аккаунттары / Test Accounts

| Роль | Email | Пароль |
|------|-------|--------|
| Студент (1-курс) | aigul@test.com | 123 |
| Студент (2-курс) | nurlan@test.com | 123 |
| Студент (3-курс) | madina@test.com | 123 |
| Әкімші / Admin | admin@test.com | admin |

## Технологиялар / Tech Stack

- **React 18** — UI library
- **Vite** — Build tool & dev server
- **Vanilla CSS-in-JS** — Styling (no external CSS frameworks)

## Сценарийлер / Scripts

```bash
npm run dev      # Start development server
npm run build    # Build for production
npm run preview  # Preview production build
```

## Жоба құрылымы / Project Structure

```
mugalim-platform/
├── src/
│   ├── App.jsx      # All components (single-file architecture)
│   └── main.jsx     # React entry point
├── index.html
├── vite.config.js
└── package.json
```

## Деплой / Deployment

### Vercel
```bash
npm run build
# Upload dist/ to Vercel, or connect GitHub repo
```

### Netlify
```bash
npm run build
# Drag & drop dist/ to Netlify, or connect GitHub repo
```

---

Made with ❤️ for MUGALIM Project
